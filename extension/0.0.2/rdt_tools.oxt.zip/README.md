# RDT Utils

Provides tools to clean up a mission document & control audio

## List of Supported Events

https://wiki.openoffice.org/wiki/Documentation/DevGuide/WritingUNO/Jobs/List_of_Supported_Events



